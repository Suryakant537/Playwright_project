var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});import{s as snapshot,n as derive,dA as throttle,cT as debounce,cC as isNull,w as makeStyles,r as reactExports,l as jsxRuntimeExports}from"./vendor-799f53a5.js";import{c3 as Order,c as createStore,eI as createAsyncState,n as ApolloClientCache,p as logger,r as reportClient,az as createSimpleAsyncAction,G as GlobalDataViewSelector,aI as navigateWithParameters,A as AppPages,v as navigate,jn as FilterTypeSearch,d1 as isActiveIssuesPage,c0 as IssuesStore,dD as fileDownloadStore,an as openSnackbar,ap as FileDownloadPoller,aq as fileDownloadService,ao as closeSnackbar,e9 as handleDownloadProgressPercentage,ea as handleFileReadyAction,B as important,cb as OxDataGrid}from"./index-a0fdc829.js";import{u as useInfinityScroll}from"./FiltersForm-e18633bf.js";import{d as useApiInventoryTable}from"./use-api-inventory-table-c9d70469.js";const sidebar={expandedSize:213,collapsedSize:32,horizontalSpacing:29},table={rowHeight:60},filters={maxHeight:300,maxHeightStatistics:200,itemHeight:40,panelHeaderHeight:27,tooltipEnterDelay:500},config={sidebar,table,filters},defaultOrderBy={field:"firstSeen",direction:Order.Desc},initialStoreValues={orderField:defaultOrderBy.field,orderDirection:defaultOrderBy.direction,loading:createAsyncState(),inventories:null,total:0,offset:0,filtersOpen:!0,selectedId:null,lastDrawerHeight:void 0,selectedInventory:null,apiItemIssuesStatistics:null,apiItemIssuesStatisticsLoading:createAsyncState(),topSearchValue:""},ApiInventoryStore=createStore(initialStoreValues,"SBOM Store"),setInventoryOffset=__name(offset=>{ApiInventoryStore.offset=offset},"setInventoryOffset"),setApiInventories=__name((inventories,update)=>{if(update)ApiInventoryStore.inventories=inventories.map((inventory,i)=>({...inventory,index:i+1}));else{const{inventories:currentInventories}=snapshot(ApiInventoryStore);ApiInventoryStore.inventories=[...currentInventories||[],...inventories.map((inventory,i)=>({...inventory,index:i+1+((currentInventories==null?void 0:currentInventories.length)||0)}))]}},"setApiInventories"),setApiItemIssuesStatistics=__name(statistics=>{ApiInventoryStore.apiItemIssuesStatistics=statistics},"setApiItemIssuesStatistics"),setInventoryTotal=__name(total=>{ApiInventoryStore.total=total},"setInventoryTotal"),toggleFiltersPanel=__name(()=>{ApiInventoryStore.filtersOpen=!ApiInventoryStore.filtersOpen},"toggleFiltersPanel"),setSelectedInventory=__name(inventory=>{ApiInventoryStore.selectedInventory=inventory},"setSelectedInventory"),setSelectedInventoryId=__name(inventory=>{ApiInventoryStore.selectedId=inventory},"setSelectedInventoryId"),setTopSearchValue=__name(value=>{ApiInventoryStore.topSearchValue=value},"setTopSearchValue");var doc$4={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GetApiSecurityItems"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}},type:{kind:"NamedType",name:{kind:"Name",value:"GetApiSecurityInput"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"getApiSecurityItems"},arguments:[{kind:"Argument",name:{kind:"Name",value:"getApiSecurityInput"},value:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"totalFiltered"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"total"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"apiSecurityItems"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"framework"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"language"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"scanId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"title"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"description"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"version"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodDescription"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodOperationId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodSummary"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"openapi"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"servers"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"epName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodResponses"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"description"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"code"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"methodTags"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appType"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"methodParameters"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"description"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"in"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"name"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"required"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"fileName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"firstSeen"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"definitions"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"source"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"fileName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"link"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"llmTitle"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"llmDescription"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"functions"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"function"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"line"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"snippet"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filepath"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"link"},arguments:[],directives:[]}]}}]}},{kind:"Field",name:{kind:"Name",value:"uuid"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"issuesBySeverity"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"appox"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"critical"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"high"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"medium"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"low"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"info"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"codeLocations"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"link"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"callBranch"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"commits"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"commitInfo"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"authorName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"authorEmail"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"committerName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"committerEmail"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"commitId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"message"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"authorDate"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"commitDate"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"match"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"snippet"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"snippetLineNumber"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"startLineNumber"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"fileName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"link"},arguments:[],directives:[]}]}}]}}]}}]}}],loc:{start:0,end:1428}};doc$4.loc.source={body:`query GetApiSecurityItems($getApiSecurityInput: GetApiSecurityInput) {
  getApiSecurityItems(getApiSecurityInput: $getApiSecurityInput) {
    totalFiltered
    total

    apiSecurityItems {
      id
      framework
      language
      scanId
      title
      description
      version
      methodDescription
      methodOperationId
      methodSummary
      openapi
      servers
      epName
      methodName
      methodResponses {
        description
        code
      }
      methodTags

      appId
      appType
      appName
      methodParameters {
        description
        in
        name
        required
      }
      fileName
      firstSeen
      definitions {
        source
        fileName
        link
        llmTitle
        llmDescription
        functions {
          function
          line
          snippet
          filepath
          link
        }
      }
      uuid
      issuesBySeverity {
        appox
        critical
        high
        medium
        low
        info
      }
      codeLocations {
        link
        callBranch
      }
      commits {
        commitInfo {
          authorName
          authorEmail
          committerName
          committerEmail
          commitId
          message
          authorDate
          commitDate
        }
        match
        snippet
        snippetLineNumber
        startLineNumber
        fileName
        link
      }
    }
  }
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function collectFragmentReferences$4(node,refs){if(node.kind==="FragmentSpread")refs.add(node.name.value);else if(node.kind==="VariableDefinition"){var type=node.type;type.kind==="NamedType"&&refs.add(type.name.value)}node.selectionSet&&node.selectionSet.selections.forEach(function(selection){collectFragmentReferences$4(selection,refs)}),node.variableDefinitions&&node.variableDefinitions.forEach(function(def){collectFragmentReferences$4(def,refs)}),node.definitions&&node.definitions.forEach(function(def){collectFragmentReferences$4(def,refs)})}__name(collectFragmentReferences$4,"collectFragmentReferences$4");var definitionRefs$4={};__name(function(){doc$4.definitions.forEach(function(def){if(def.name){var refs=new Set;collectFragmentReferences$4(def,refs),definitionRefs$4[def.name.value]=refs}})},"extractReferences")();function findOperation$4(doc2,name){for(var i=0;i<doc2.definitions.length;i++){var element=doc2.definitions[i];if(element.name&&element.name.value==name)return element}}__name(findOperation$4,"findOperation$4");function oneQuery$4(doc2,operationName){var newDoc={kind:doc2.kind,definitions:[findOperation$4(doc2,operationName)]};doc2.hasOwnProperty("loc")&&(newDoc.loc=doc2.loc);var opRefs=definitionRefs$4[operationName]||new Set,allRefs=new Set,newRefs=new Set;for(opRefs.forEach(function(refName){newRefs.add(refName)});newRefs.size>0;){var prevRefs=newRefs;newRefs=new Set,prevRefs.forEach(function(refName){if(!allRefs.has(refName)){allRefs.add(refName);var childRefs=definitionRefs$4[refName]||new Set;childRefs.forEach(function(childRef){newRefs.add(childRef)})}})}return allRefs.forEach(function(refName){var op=findOperation$4(doc2,refName);op&&newDoc.definitions.push(op)}),newDoc}__name(oneQuery$4,"oneQuery$4");oneQuery$4(doc$4,"GetApiSecurityItems");const getApiInventories=__name(client=>({execute:async(getApiSecurityInput,cache=!0)=>{try{return(await client.query({query:doc$4,variables:{getApiSecurityInput},fetchPolicy:cache?ApolloClientCache.CacheFirst:ApolloClientCache.NetworkOnly})).data.getApiSecurityItems}catch(error){return logger.error("Failed to fetch api inventories",error),null}}}),"getApiInventories");var doc$3={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GetApiSecurityFilters"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}},type:{kind:"NamedType",name:{kind:"Name",value:"GetApiSecurityInput"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"getApiSecurityFilters"},arguments:[{kind:"Argument",name:{kind:"Name",value:"getApiSecurityInput"},value:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"total"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"apps"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"titles"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"endpoints"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"methods"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"framework"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"source"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"severities"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"languages"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"reachability"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]}]}}]}}]}}],loc:{start:0,end:905}};doc$3.loc.source={body:`query GetApiSecurityFilters($getApiSecurityInput: GetApiSecurityInput) {
  getApiSecurityFilters(getApiSecurityInput: $getApiSecurityInput) {
    total
    apps {
      id
      filterId
      label
      count
      percent
    }
    titles {
      id
      filterId
      label
      count
      percent
    }
    endpoints {
      id
      filterId
      label
      count
      percent
    }
    methods {
      id
      filterId
      label
      count
      percent
    }
    framework {
      id
      filterId
      label
      count
      percent
    }
    source {
      id
      filterId
      label
      count
      percent
    }
    severities {
      id
      filterId
      label
      count
      percent
    }
    languages {
      id
      filterId
      label
      count
      percent
    }
    reachability {
      id
      filterId
      label
      count
      percent
    }
  }
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function collectFragmentReferences$3(node,refs){if(node.kind==="FragmentSpread")refs.add(node.name.value);else if(node.kind==="VariableDefinition"){var type=node.type;type.kind==="NamedType"&&refs.add(type.name.value)}node.selectionSet&&node.selectionSet.selections.forEach(function(selection){collectFragmentReferences$3(selection,refs)}),node.variableDefinitions&&node.variableDefinitions.forEach(function(def){collectFragmentReferences$3(def,refs)}),node.definitions&&node.definitions.forEach(function(def){collectFragmentReferences$3(def,refs)})}__name(collectFragmentReferences$3,"collectFragmentReferences$3");var definitionRefs$3={};__name(function(){doc$3.definitions.forEach(function(def){if(def.name){var refs=new Set;collectFragmentReferences$3(def,refs),definitionRefs$3[def.name.value]=refs}})},"extractReferences")();function findOperation$3(doc2,name){for(var i=0;i<doc2.definitions.length;i++){var element=doc2.definitions[i];if(element.name&&element.name.value==name)return element}}__name(findOperation$3,"findOperation$3");function oneQuery$3(doc2,operationName){var newDoc={kind:doc2.kind,definitions:[findOperation$3(doc2,operationName)]};doc2.hasOwnProperty("loc")&&(newDoc.loc=doc2.loc);var opRefs=definitionRefs$3[operationName]||new Set,allRefs=new Set,newRefs=new Set;for(opRefs.forEach(function(refName){newRefs.add(refName)});newRefs.size>0;){var prevRefs=newRefs;newRefs=new Set,prevRefs.forEach(function(refName){if(!allRefs.has(refName)){allRefs.add(refName);var childRefs=definitionRefs$3[refName]||new Set;childRefs.forEach(function(childRef){newRefs.add(childRef)})}})}return allRefs.forEach(function(refName){var op=findOperation$3(doc2,refName);op&&newDoc.definitions.push(op)}),newDoc}__name(oneQuery$3,"oneQuery$3");oneQuery$3(doc$3,"GetApiSecurityFilters");const getApiInventoriesFilters=__name((client,cache=!0)=>({execute:async getApiSecurityInput=>{const results=await client.query({query:doc$3,variables:{getApiSecurityInput},fetchPolicy:cache?ApolloClientCache.CacheFirst:ApolloClientCache.NetworkOnly});return results.data?results.data.getApiSecurityFilters:null}}),"getApiInventoriesFilters");var doc$2={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GetSbomLibraries"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"getSbomLibrariesInput"}},type:{kind:"NamedType",name:{kind:"Name",value:"GetApplicationsSbom"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"getSbomLibraries"},arguments:[{kind:"Argument",name:{kind:"Name",value:"getApplicationsSbom"},value:{kind:"Variable",name:{kind:"Name",value:"getSbomLibrariesInput"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"sbomLibs"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"id"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appType"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"libId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"libraryName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"libraryVersion"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"license"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"dependencyType"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"source"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"location"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appId"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"locationLink"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"appLink"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"pkgName"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"copyWriteInfo"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"copyWriteInfoLink"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"libLink"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"artifactInSbomLibs"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"image"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"imageLink"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"imageCreatedAt"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"sha"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"os"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"osVersion"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"baseImage"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"baseImageVersion"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"tag"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"layer"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"registryName"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"vulnerabilityCounts"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"appox"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"critical"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"high"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"medium"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"low"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"info"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"triggerPackage"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"notPopular"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"licenseIssue"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"notMaintained"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"isDeprecated"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"dependencyLevel"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"notUpdated"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"notImported"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"offset"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"total"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"totalFilteredSbomLibs"},arguments:[],directives:[]}]}}]}}],loc:{start:0,end:972}};doc$2.loc.source={body:`query GetSbomLibraries($getSbomLibrariesInput: GetApplicationsSbom) {
  getSbomLibraries(getApplicationsSbom: $getSbomLibrariesInput) {
    sbomLibs {
      id
      appType
      libId
      libraryName
      libraryVersion
      license
      appName
      dependencyType
      source
      location
      appId
      locationLink
      appLink
      pkgName
      copyWriteInfo
      copyWriteInfoLink
      libLink
      artifactInSbomLibs {
        image
        imageLink
        imageCreatedAt
        sha
        os
        osVersion
        baseImage
        baseImageVersion
        tag
        layer
        registryName
      }
      vulnerabilityCounts {
        appox
        critical
        high
        medium
        low
        info
      }
      triggerPackage
      notPopular
      licenseIssue
      notMaintained
      isDeprecated
      dependencyLevel
      notUpdated
      notImported
    }
    offset
    total
    totalFilteredSbomLibs
  }
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function collectFragmentReferences$2(node,refs){if(node.kind==="FragmentSpread")refs.add(node.name.value);else if(node.kind==="VariableDefinition"){var type=node.type;type.kind==="NamedType"&&refs.add(type.name.value)}node.selectionSet&&node.selectionSet.selections.forEach(function(selection){collectFragmentReferences$2(selection,refs)}),node.variableDefinitions&&node.variableDefinitions.forEach(function(def){collectFragmentReferences$2(def,refs)}),node.definitions&&node.definitions.forEach(function(def){collectFragmentReferences$2(def,refs)})}__name(collectFragmentReferences$2,"collectFragmentReferences$2");var definitionRefs$2={};__name(function(){doc$2.definitions.forEach(function(def){if(def.name){var refs=new Set;collectFragmentReferences$2(def,refs),definitionRefs$2[def.name.value]=refs}})},"extractReferences")();function findOperation$2(doc2,name){for(var i=0;i<doc2.definitions.length;i++){var element=doc2.definitions[i];if(element.name&&element.name.value==name)return element}}__name(findOperation$2,"findOperation$2");function oneQuery$2(doc2,operationName){var newDoc={kind:doc2.kind,definitions:[findOperation$2(doc2,operationName)]};doc2.hasOwnProperty("loc")&&(newDoc.loc=doc2.loc);var opRefs=definitionRefs$2[operationName]||new Set,allRefs=new Set,newRefs=new Set;for(opRefs.forEach(function(refName){newRefs.add(refName)});newRefs.size>0;){var prevRefs=newRefs;newRefs=new Set,prevRefs.forEach(function(refName){if(!allRefs.has(refName)){allRefs.add(refName);var childRefs=definitionRefs$2[refName]||new Set;childRefs.forEach(function(childRef){newRefs.add(childRef)})}})}return allRefs.forEach(function(refName){var op=findOperation$2(doc2,refName);op&&newDoc.definitions.push(op)}),newDoc}__name(oneQuery$2,"oneQuery$2");oneQuery$2(doc$2,"GetSbomLibraries");const getSingleApiInventory=__name(client=>({execute:async getSingleApiInventoryInput=>{try{return(await client.query({query:doc$2,variables:{getSingleApiInventoryInput},fetchPolicy:ApolloClientCache.NetworkOnly})).data.getSingleApiInventory}catch(error){return logger.error("Failed to fetch api inventories",error),null}}}),"getSingleApiInventory");var doc$1={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GetApiSecurityItemsCsv"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}},type:{kind:"NamedType",name:{kind:"Name",value:"GetApiSecurityInput"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"getApiSecurityItemsCsv"},arguments:[{kind:"Argument",name:{kind:"Name",value:"getApiSecurityInput"},value:{kind:"Variable",name:{kind:"Name",value:"getApiSecurityInput"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"requestId"},arguments:[],directives:[]}]}}]}}],loc:{start:0,end:164}};doc$1.loc.source={body:`query GetApiSecurityItemsCsv($getApiSecurityInput: GetApiSecurityInput) {
  getApiSecurityItemsCsv(getApiSecurityInput: $getApiSecurityInput) {
    requestId
  }
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function collectFragmentReferences$1(node,refs){if(node.kind==="FragmentSpread")refs.add(node.name.value);else if(node.kind==="VariableDefinition"){var type=node.type;type.kind==="NamedType"&&refs.add(type.name.value)}node.selectionSet&&node.selectionSet.selections.forEach(function(selection){collectFragmentReferences$1(selection,refs)}),node.variableDefinitions&&node.variableDefinitions.forEach(function(def){collectFragmentReferences$1(def,refs)}),node.definitions&&node.definitions.forEach(function(def){collectFragmentReferences$1(def,refs)})}__name(collectFragmentReferences$1,"collectFragmentReferences$1");var definitionRefs$1={};__name(function(){doc$1.definitions.forEach(function(def){if(def.name){var refs=new Set;collectFragmentReferences$1(def,refs),definitionRefs$1[def.name.value]=refs}})},"extractReferences")();function findOperation$1(doc2,name){for(var i=0;i<doc2.definitions.length;i++){var element=doc2.definitions[i];if(element.name&&element.name.value==name)return element}}__name(findOperation$1,"findOperation$1");function oneQuery$1(doc2,operationName){var newDoc={kind:doc2.kind,definitions:[findOperation$1(doc2,operationName)]};doc2.hasOwnProperty("loc")&&(newDoc.loc=doc2.loc);var opRefs=definitionRefs$1[operationName]||new Set,allRefs=new Set,newRefs=new Set;for(opRefs.forEach(function(refName){newRefs.add(refName)});newRefs.size>0;){var prevRefs=newRefs;newRefs=new Set,prevRefs.forEach(function(refName){if(!allRefs.has(refName)){allRefs.add(refName);var childRefs=definitionRefs$1[refName]||new Set;childRefs.forEach(function(childRef){newRefs.add(childRef)})}})}return allRefs.forEach(function(refName){var op=findOperation$1(doc2,refName);op&&newDoc.definitions.push(op)}),newDoc}__name(oneQuery$1,"oneQuery$1");oneQuery$1(doc$1,"GetApiSecurityItemsCsv");const getExportedApiItems=__name(client=>({execute:async getApiSecurityInput=>{try{const results=await client.query({query:doc$1,fetchPolicy:ApolloClientCache.NoCache,variables:{getApiSecurityInput}});return results.data?results.data.getApiSecurityItemsCsv:null}catch(error){return logger.error("Failed to export csv",error),null}}}),"getExportedApiItems");var doc={kind:"Document",definitions:[{kind:"OperationDefinition",operation:"query",name:{kind:"Name",value:"GetIssuesFilters"},variableDefinitions:[{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"getIssuesInput"}},type:{kind:"NamedType",name:{kind:"Name",value:"IssuesInput"}},directives:[]},{kind:"VariableDefinition",variable:{kind:"Variable",name:{kind:"Name",value:"isDemo"}},type:{kind:"NamedType",name:{kind:"Name",value:"Boolean"}},directives:[]}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"getIssuesFilters"},arguments:[{kind:"Argument",name:{kind:"Name",value:"getIssuesInput"},value:{kind:"Variable",name:{kind:"Name",value:"getIssuesInput"}}},{kind:"Argument",name:{kind:"Name",value:"isDemo"},value:{kind:"Variable",name:{kind:"Name",value:"isDemo"}}}],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"criticality"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"categories"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"issueOwners"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]}]}},{kind:"Field",name:{kind:"Name",value:"sourceTools"},arguments:[],directives:[],selectionSet:{kind:"SelectionSet",selections:[{kind:"Field",name:{kind:"Name",value:"label"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"count"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"percent"},arguments:[],directives:[]},{kind:"Field",name:{kind:"Name",value:"filterId"},arguments:[],directives:[]}]}}]}}]}}],loc:{start:0,end:457}};doc.loc.source={body:`query GetIssuesFilters($getIssuesInput: IssuesInput, $isDemo: Boolean) {
  getIssuesFilters(getIssuesInput: $getIssuesInput, isDemo: $isDemo) {
    criticality {
      label
      count
      percent
      filterId
    }
    categories {
      label
      count
      percent
      filterId
    }
    issueOwners {
      label
      count
      percent
      filterId
    }
    sourceTools {
      label
      count
      percent
      filterId
    }
  }
}
`,name:"GraphQL request",locationOffset:{line:1,column:1}};function collectFragmentReferences(node,refs){if(node.kind==="FragmentSpread")refs.add(node.name.value);else if(node.kind==="VariableDefinition"){var type=node.type;type.kind==="NamedType"&&refs.add(type.name.value)}node.selectionSet&&node.selectionSet.selections.forEach(function(selection){collectFragmentReferences(selection,refs)}),node.variableDefinitions&&node.variableDefinitions.forEach(function(def){collectFragmentReferences(def,refs)}),node.definitions&&node.definitions.forEach(function(def){collectFragmentReferences(def,refs)})}__name(collectFragmentReferences,"collectFragmentReferences");var definitionRefs={};__name(function(){doc.definitions.forEach(function(def){if(def.name){var refs=new Set;collectFragmentReferences(def,refs),definitionRefs[def.name.value]=refs}})},"extractReferences")();function findOperation(doc2,name){for(var i=0;i<doc2.definitions.length;i++){var element=doc2.definitions[i];if(element.name&&element.name.value==name)return element}}__name(findOperation,"findOperation");function oneQuery(doc2,operationName){var newDoc={kind:doc2.kind,definitions:[findOperation(doc2,operationName)]};doc2.hasOwnProperty("loc")&&(newDoc.loc=doc2.loc);var opRefs=definitionRefs[operationName]||new Set,allRefs=new Set,newRefs=new Set;for(opRefs.forEach(function(refName){newRefs.add(refName)});newRefs.size>0;){var prevRefs=newRefs;newRefs=new Set,prevRefs.forEach(function(refName){if(!allRefs.has(refName)){allRefs.add(refName);var childRefs=definitionRefs[refName]||new Set;childRefs.forEach(function(childRef){newRefs.add(childRef)})}})}return allRefs.forEach(function(refName){var op=findOperation(doc2,refName);op&&newDoc.definitions.push(op)}),newDoc}__name(oneQuery,"oneQuery");oneQuery(doc,"GetIssuesFilters");const fetchIssuesStatistics=__name(client=>({execute:async(getIssuesInput,cache=!0,isDemo=!1)=>{try{const results=await client.query({query:doc,fetchPolicy:cache?ApolloClientCache.CacheFirst:ApolloClientCache.NoCache,variables:{getIssuesInput,isDemo}});return results.data?results.data.getIssuesFilters:null}catch(e){return logger.error("Failed to fetch issues filters",e),null}}}),"fetchIssuesStatistics"),apiInventoryService={getIssuesStatistics:fetchIssuesStatistics(reportClient),getApiInventories:getApiInventories(reportClient),getApiInventoriesFilters:getApiInventoriesFilters(reportClient),getSingleInventory:getSingleApiInventory(reportClient),exportApiItems:getExportedApiItems(reportClient)},initialSbomFiltersStoreValues={loadingFilters:createAsyncState(),inventoriesFilterValue:"",inventoriesFiltersTypeSearch:null,inventoriesFiltersType:null,filterBy:{},totalFilters:0,searchValues:[]},baseStore=createStore(initialSbomFiltersStoreValues,"Api Inventory Filters Store"),ApiInventoryFiltersStore=derive({numberOfFilters:get=>{const{filterBy}=get(baseStore);return Object.keys(filterBy).reduce((acc,key)=>acc+filterBy[key].length,0)||0}},{proxy:baseStore}),loadApiInventoryFilters=createSimpleAsyncAction(async(cache=!0,limit=100)=>{const{selectedTagIds,selectedAppOwnersEmails}=snapshot(GlobalDataViewSelector),{filterBy}=snapshot(ApiInventoryFiltersStore),{offset,topSearchValue}=snapshot(ApiInventoryStore),results=await apiInventoryService.getApiInventoriesFilters.execute({limit,offset,filters:filterBy,search:topSearchValue,owners:selectedAppOwnersEmails,tagIds:selectedTagIds});results&&(setStoreInventoriesFilters(results),setStoreInventoriesFiltersTypeSearch(results))},{asyncState:ApiInventoryFiltersStore.loadingFilters,errorMessage:"Failed to load libraries filters"}),onChangeFilter=throttle(e=>{const{loadingFilters}=snapshot(ApiInventoryFiltersStore),{loading}=snapshot(ApiInventoryStore);if(!(loadingFilters.isPending()||loading.isPending())){if(ApiInventoryFiltersStore.filterBy[e.target.id]){const index=ApiInventoryFiltersStore.filterBy[e.target.id].indexOf(e.target.value);index!==-1?ApiInventoryFiltersStore.filterBy[e.target.id].splice(index,1):ApiInventoryFiltersStore.filterBy[e.target.id].push(e.target.value)}else ApiInventoryFiltersStore.filterBy[e.target.id]=[e.target.value];selectInventory(),navigateWithParameters(AppPages.ApiInventory,{filters:ApiInventoryFiltersStore.filterBy}),loadApiInventories({update:!0}),loadApiInventoryFilters()}},1e3),setInitialFilters=__name(encodedFilters=>{if(!encodedFilters)return;let filters2={};try{filters2=JSON.parse(decodeURI(encodedFilters))}catch{}ApiInventoryFiltersStore.filterBy=filters2},"setInitialFilters"),setTotalInventoryFilters=__name(totalFilters=>{ApiInventoryFiltersStore.totalFilters=totalFilters},"setTotalInventoryFilters"),clearFilters=__name(()=>{ApiInventoryFiltersStore.filterBy={},ApiInventoryFiltersStore.numberOfFilters=0,navigate(AppPages.ApiInventory),loadApiInventories({update:!0}),loadApiInventoryFilters()},"clearFilters"),setStoreInventoriesFilters=__name(filters2=>{ApiInventoryFiltersStore.inventoriesFiltersType=filters2},"setStoreInventoriesFilters"),setStoreInventoriesFiltersTypeSearch=__name(filtersTypeSearch=>{const{searchValues}=snapshot(ApiInventoryFiltersStore);ApiInventoryFiltersStore.inventoriesFiltersTypeSearch=Object.keys(filtersTypeSearch).reduce((acc,key)=>(acc[key]=searchValues[key]?filtersTypeSearch[key].filter(f=>f.label.toLocaleLowerCase().includes(searchValues[key].toLowerCase())):filtersTypeSearch[key],acc),{})},"setStoreInventoriesFiltersTypeSearch"),handleSearchFilterType=__name((searchInput,filterType)=>{const{inventoriesFiltersType}=snapshot(ApiInventoryFiltersStore);if(searchInput===""){const index=ApiInventoryFiltersStore.searchValues.findIndex(key=>key.fieldName===filterType);ApiInventoryFiltersStore.searchValues[index].value="",setStoreInventoriesFiltersTypeSearch({...inventoriesFiltersType});return}if(inventoriesFiltersType&&filterType){const newFilteredTypes=inventoriesFiltersType[filterType].filter(filterType2=>filterType2.label.toLocaleLowerCase().includes(searchInput.toLowerCase()));setSearchValue(filterType,searchInput),setStoreInventoriesFiltersTypeSearch({...inventoriesFiltersType,[FilterTypeSearch[filterType]]:newFilteredTypes})}},"handleSearchFilterType"),setSearchValue=__name((type,searchValue)=>{const index=ApiInventoryFiltersStore.searchValues.findIndex(key=>key.fieldName===type);index!==-1?ApiInventoryFiltersStore.searchValues[index].value=searchValue:ApiInventoryFiltersStore.searchValues.push({fieldName:type,value:searchValue})},"setSearchValue"),sortApiInventory=__name(field=>{field?sortByField(field):sortByDefault()},"sortApiInventory"),sortByDefault=__name(()=>{ApiInventoryStore.orderField===defaultOrderBy.field?ApiInventoryStore.orderDirection=ApiInventoryStore.orderDirection===Order.Asc?Order.Desc:Order.Asc:(ApiInventoryStore.orderField=defaultOrderBy.field,ApiInventoryStore.orderDirection=defaultOrderBy.direction),executeSort()},"sortByDefault"),sortByField=__name(field=>{ApiInventoryStore.orderDirection=ApiInventoryStore.orderField===field?ApiInventoryStore.orderDirection===Order.Asc?Order.Desc:Order.Asc:Order.Asc,ApiInventoryStore.orderField=field,executeSort()},"sortByField"),executeSort=__name(()=>{ApiInventoryStore.offset=0,loadApiInventories({update:!0})},"executeSort"),loadApiInventories=createSimpleAsyncAction(async params=>{const{update=!1,cache=!0}=params||{},{selectedTagIds,selectedAppOwnersEmails}=snapshot(GlobalDataViewSelector);update&&(ApiInventoryStore.offset=0);const{total,offset,orderField,orderDirection,topSearchValue}=snapshot(ApiInventoryStore);if(total<offset)return;const response=await apiInventoryService.getApiInventories.execute({offset,orderBy:{field:orderField,direction:orderDirection},filters:isActiveIssuesPage()?{issueIds:[IssuesStore.selectedIssueId]}:ApiInventoryFiltersStore.filterBy,search:topSearchValue,limit:50,owners:selectedAppOwnersEmails,tagIds:selectedTagIds},cache);if(response&&response.apiSecurityItems){const{apiSecurityItems,total:total2,totalFiltered}=response;setInventoryOffset(offset+response.apiSecurityItems.length),setApiInventories(apiSecurityItems,update),setInventoryTotal(total2),setTotalInventoryFilters(totalFiltered),apiSecurityItems.length===1&&!isActiveIssuesPage()&&selectInventory(apiSecurityItems[0].id)}},{asyncState:ApiInventoryStore.loading,errorMessage:"Failed to load sbom libraries"}),loadStatistics=createSimpleAsyncAction(async(apiItem,cache=!0)=>{const results=await apiInventoryService.getIssuesStatistics.execute({filters:{apiItem:[apiItem]}},cache);results&&setApiItemIssuesStatistics(results)},{asyncState:ApiInventoryStore.apiItemIssuesStatisticsLoading,errorMessage:"Failed to load issues statistics"}),selectInventory=__name(async inventoryId=>{const{inventories}=snapshot(ApiInventoryStore),inventory=(inventories==null?void 0:inventories.find(i=>i.id===inventoryId))||null;setSelectedInventory(inventory),setSelectedInventoryId(inventoryId||null);const currentUrl=new URL(window.location.href),params=new URLSearchParams(currentUrl.search);inventoryId?params.set("apiInventoryId",inventoryId):params.delete("apiInventoryId"),navigate(AppPages.ApiInventory,params.toString())},"selectInventory"),exportApiItemsToFile=__name(async({applyFilters})=>{const snackBarKey="download-csv-api-snackbar",handleDownloadFinished=__name(()=>{fileDownloadStore.apiItemsCsvDownloadInProgress=!1,fileDownloadStore.downloadProgress=0,closeSnackbar(snackBarKey)},"handleDownloadFinished");try{const{orderDirection,orderField,total,topSearchValue}=snapshot(ApiInventoryStore),{filterBy}=snapshot(ApiInventoryFiltersStore),{downloadProgress}=snapshot(fileDownloadStore);fileDownloadStore.apiItemsCsvDownloadInProgress=!0,openSnackbar("Exporting API's to CSV",{variant:"default",persist:!0,key:snackBarKey},{hideCloseIcon:!1,isShowingSpinner:!0,spinnerVariant:"determinate",value:downloadProgress,valueCb:()=>snapshot(fileDownloadStore).downloadProgress});const response=await apiInventoryService.exportApiItems.execute(applyFilters?{orderBy:{field:orderField,direction:orderDirection},filters:filterBy,search:topSearchValue}:{orderBy:{}});if(isNull(response)||!response.requestId){handleDownloadFinished(),openSnackbar("Failed generating csv, please try again later",{variant:"error"});return}const poller=new FileDownloadPoller(()=>fileDownloadService.fetchReadyFile.execute({requestId:response.requestId}),response2=>response2?response2.error?(closeSnackbar(snackBarKey),openSnackbar("Failed generating csv, please try again later",{variant:"error"}),!1):(handleDownloadProgressPercentage(total),response2.isFileReady&&handleFileReadyAction(response2,"Successfully downloaded API's CSV file"),!response2.isFileReady):!1,()=>{},handleDownloadFinished);poller.startPolling(),setTimeout(()=>{poller.cancelPolling()},12e5)}catch(error){logger.error(error),handleDownloadFinished(),openSnackbar("Export to CSV file failed. Please try again later...",{variant:"warning"})}},"exportApiItemsToFile"),onTopSearchChange=debounce(e=>{setTopSearchValue(e.target.value),loadApiInventories({update:!0}),loadApiInventoryFilters()},500),ApiInventoryTable=__name(({inventories,loading,selectedId,offset,orderDirection,orderField})=>{const{classes}=useStyles(),columns=useApiInventoryTable(classes),tableRef=reactExports.useRef(null);reactExports.useEffect(()=>{var _a;offset===0&&((_a=tableRef.current)==null||_a.scrollToRow(0))},[offset]);const{onScroll}=useInfinityScroll({load:loadApiInventories,threshold:.9,loading}),onRowClick=reactExports.useCallback(row=>{selectInventory(row.id)},[]),sortColumnsInfo=reactExports.useMemo(()=>orderField&&orderDirection?[{columnKey:orderField,direction:orderDirection}]:void 0,[orderField,orderDirection]);return jsxRuntimeExports.jsx("div",{className:classes.tableContainer,children:jsxRuntimeExports.jsx(OxDataGrid,{tableRef,activeRowValue:selectedId,activeRowKey:"id",rowHeight:config.table.rowHeight,onScroll,columns,rows:inventories,loading,onSort:sortApiInventory,sortColumns:sortColumnsInfo,onRowClick})})},"ApiInventoryTable"),useStyles=makeStyles()({tableContainer:{borderRadius:10,overflow:"hidden",width:"100%",height:"100%",position:"relative"},textCenter:{textAlign:important("center")},flexCenter:{justifyContent:"center"},headerCell:{overflowWrap:"break-word"},noPadding:{paddingInline:important("0")},textOverFlow:{lineHeight:1,whiteSpace:"normal",wordWrap:"break-word",overflowWrap:"break-word",maxWidth:"100%"},columnsContainer:{display:"flex",flexDirection:"column",gap:5}});export{ApiInventoryStore as A,ApiInventoryTable as a,ApiInventoryFiltersStore as b,config as c,clearFilters as d,loadStatistics as e,exportApiItemsToFile as f,onTopSearchChange as g,handleSearchFilterType as h,setInitialFilters as i,loadApiInventoryFilters as j,loadApiInventories as l,onChangeFilter as o,selectInventory as s,toggleFiltersPanel as t};
//# sourceMappingURL=ApiInventoryTable-6392c7b4.js.map
